package com.example.dao;
import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;

@Entity(tableName = "locality")
public class LocationDetails implements Serializable {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private int id;

    @NonNull
    @ColumnInfo(name = "location")
    private String location;

    public LocationDetails(int id, String location) {
        this.id=id;
        this.location=location;
    }

    public int getId(){return this.id;}
    public void setId(int id){this.id=id;}

    @NonNull
    public String getLocation() {
        return location;
    }

    public void setLocation(@NonNull String location) {
        this.location = location;
    }

}
