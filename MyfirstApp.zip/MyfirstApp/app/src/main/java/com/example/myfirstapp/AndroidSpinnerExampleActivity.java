package com.example.myfirstapp;

import java.util.List;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;
import com.example.dao.BloodBankDatabase;
import com.example.dao.PopulateDbAsync;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;


public class AndroidSpinnerExampleActivity extends AppCompatActivity implements OnItemSelectedListener
{
    private static final String DATABASE_NAME = "bb_db";
    private BloodBankDatabase bbDatabase;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.main);

            if(bbDatabase==null) {
                bbDatabase = BloodBankDatabase.getDatabase(getApplicationContext());
               //new PopulateDbAsync(bbDatabase).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);

                //System.out.println("DB Record Creation started");

                /*new Thread(new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("DB Record populateLocationData complted");
                        bbDatabase.dataDao().insertMultipleLocations(EmployeeBloodGroupDAO.populateLocationData());
                    }
                }).start();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("DB Record populateSubLocationData complted");
                        bbDatabase.dataDao().insertMultipleSubLocations(EmployeeBloodGroupDAO.populateSubLocationData());
                    }
                }).start();
                new Thread(new Runnable() {
                    @Override
                    public void run() {System.out.println("DB Record populateEmployeeData complted");

                        bbDatabase.dataDao().insertMultipleEmployeeDetails(EmployeeBloodGroupDAO.populateEmployeeData());
                    }

                    //new BloodBankDatabase.PopulateDbAsync(bbDatabase).execute();
                }).start();*/
                //System.out.println("DB Record Insertion complted");
            }
            // Spinner element
            Spinner locspinner = findViewById(R.id.locspinner);
           // Spinner dcLocspinner = findViewById(R.id.dcLocspinner);
            // Spinner bloodGroupspinner = findViewById(R.id.bloodGroupspinner);
            // Spinner click listener
            locspinner.setOnItemSelectedListener(this);

            // Spinner Drop down elements
            LiveData<List<String>> locationList = bbDatabase.dataDao().getAllLocations();

            // Creating adapter for spinner
            ArrayAdapter<String> locDataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,locationList.getValue());

            // Drop down layout style - list view with radio button
            locDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            // attaching data adapter to spinner
            locspinner.setAdapter(locDataAdapter);

                      // Spinner click listener
           /* dcLocspinner.setOnItemSelectedListener(this);

            // Spinner Drop down elements
            List<String> dcLocationList = new ArrayList<String>();
            dcLocationList.add("Business Services");
            dcLocationList.add("Computers");
            dcLocationList.add("Travel");

            // Creating adapter for spinner
            ArrayAdapter<String> dcLocDataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,dcLocationList);

            // Drop down layout style - list view with radio button
            dcLocDataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            // attaching data adapter to spinner
            dcLocspinner.setAdapter(dcLocDataAdapter);

            // Spinner click listener
          //  bloodGroupspinner.setOnItemSelectedListener(this);

            // Spinner Drop down elements
            List<String> bloodGroupList = new ArrayList<String>();
            bloodGroupList.add("A+");
            bloodGroupList.add("A-");
            bloodGroupList.add("B+");
            bloodGroupList.add("B-");
            bloodGroupList.add("AB+");
            bloodGroupList.add("AB-");
            bloodGroupList.add("O+");
            bloodGroupList.add("O-");

            // Creating adapter for spinner
            ArrayAdapter<String> bloodGroupAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,bloodGroupList);

            // Drop down layout style - list view with radio button
            bloodGroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            // attaching data adapter to spinner
            //bloodGroupspinner.setAdapter(bloodGroupAdapter);*/


        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            // On selecting a spinner item
            String item = parent.getItemAtPosition(position).toString();

            // Showing selected spinner item
            Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
        }
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }

    public static String getDatabaseName() {
        return DATABASE_NAME;
    }

    public void setBbDatabase(BloodBankDatabase bbDatabase) {
        this.bbDatabase = bbDatabase;
    }




    }
