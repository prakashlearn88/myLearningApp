package com.example.dao;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.myfirstapp.AndroidSpinnerExampleActivity;

import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;


@Database(entities = {EmployeeDetails.class,LocationDetails.class,SubLocationDetails.class}, version = 1, exportSchema = false)
public abstract class BloodBankDatabase extends RoomDatabase {

    private static volatile BloodBankDatabase INSTANCE;

    public abstract EmployeeBloodGroupDAO dataDao();

   public static BloodBankDatabase getDatabase(final Context context) {
       System.out.println("DB instance Creation started");
       if (INSTANCE == null) {
           synchronized (BloodBankDatabase.class) {
               if (INSTANCE == null) {
                   INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                           BloodBankDatabase.class, "bb_db")
                           .allowMainThreadQueries()
                           .addCallback(new RoomDatabase.Callback() {
                               @Override
                               public void onCreate(@NonNull SupportSQLiteDatabase db) {
                                   super.onCreate(db);
                                   Log.d("Details", "populating with data...");
                                   new PopulateDbAsync(INSTANCE).execute();
                               }
                           })
                           .build();
               }
           }
       }
       System.out.println("DB instance Creation successfull");

       return INSTANCE;
    }

}

