package com.example.dao;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "SubLocation")
public class SubLocationDetails implements Serializable {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "lid")
    private int lid;


    @NonNull
    @ColumnInfo(name = "dcLocation")
    private String dcLocation;

    public SubLocationDetails(int lid, String dcLocation) {
        this.lid=lid;
        this.dcLocation=dcLocation;
    }

    public int getLid(){return this.lid;}

    public void setLid(int id){this.lid=id;}


    @NonNull
    public String getDcLocation() {
        return dcLocation;
    }

    public void setDcLocation(@NonNull String dcLocation) {
        this.dcLocation = dcLocation;
    }


}
