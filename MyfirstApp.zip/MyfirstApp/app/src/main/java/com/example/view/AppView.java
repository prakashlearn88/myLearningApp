package com.example.view;

import android.app.Application;

import com.example.repository.BloodBankRepo;

import java.util.List;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class AppView extends AndroidViewModel {

    private BloodBankRepo bloodBankRepo;
    //private LiveData<List<String>> location;
    private LiveData<List<String>> location;
    private LiveData<List<String>> sublocation;

    public AppView (Application application) {
        super(application);
        bloodBankRepo = new BloodBankRepo(application);
        location = bloodBankRepo.getAllLocations();
        sublocation = bloodBankRepo.getAllSubLocations();
    }

}

