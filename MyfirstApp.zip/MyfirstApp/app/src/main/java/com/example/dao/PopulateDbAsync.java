package com.example.dao;

import android.os.AsyncTask;

public class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

    private final EmployeeBloodGroupDAO employeeBloodGroupDAO;

    public PopulateDbAsync(BloodBankDatabase db) {
        employeeBloodGroupDAO = db.dataDao();
    }

    @Override
    protected Void doInBackground(final Void... params) {
        System.out.println("DB Record Creation started");
        employeeBloodGroupDAO.insertMultipleLocations(EmployeeBloodGroupDAO.populateLocationData());
        employeeBloodGroupDAO.insertMultipleSubLocations(EmployeeBloodGroupDAO.populateSubLocationData());
        employeeBloodGroupDAO.insertMultipleEmployeeDetails(EmployeeBloodGroupDAO.populateEmployeeData());
        System.out.println("DB Record Insertion complted");
        return null;
    }
    protected void onPreExecute(final Void... params) {
        System.out.println("onPreExecute Record Creation started");
        employeeBloodGroupDAO.insertMultipleLocations(EmployeeBloodGroupDAO.populateLocationData());
        employeeBloodGroupDAO.insertMultipleSubLocations(EmployeeBloodGroupDAO.populateSubLocationData());
        employeeBloodGroupDAO.insertMultipleEmployeeDetails(EmployeeBloodGroupDAO.populateEmployeeData());
        System.out.println("onPreExecute Record Insertion complted");

    }
}