package com.app.bb;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import bb.R;

public class DetailsActivity extends Activity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);
        DbHelper db = new DbHelper(this);
        Bundle bundle=getIntent().getExtras();
        String dcLocation=bundle.get("dcLocation").toString();
        String bloodGroup=bundle.get("bloodGroup").toString();
        System.out.println("dcLocation-->"+dcLocation);
        System.out.println("dcLocation-->"+dcLocation);
        ArrayList<HashMap<String, String>>  empList = db.getEmployeeDetails(dcLocation,bloodGroup);
        ListView lv = (ListView) findViewById(R.id.empList);
        ListAdapter adapter = new SimpleAdapter(DetailsActivity.this, empList, R.layout.list_row,new String[]{"name","contactnumber","dclocation"}, new int[]{R.id.name, R.id.contactnumber, R.id.dclocation});
        lv.setAdapter(adapter);
        Button back = (Button)findViewById(R.id.btnBack);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(DetailsActivity.this, MyAppActivity.class);
                startActivity(intent);

            }
        });
    }
}