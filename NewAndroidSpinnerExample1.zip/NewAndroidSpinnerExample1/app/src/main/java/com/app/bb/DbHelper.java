package com.app.bb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper{
	 // Database Version
    private static final int DB_VERSION = 1;

    // Database Name
    private static final String DB_NAME = "bb.db";


    // Table name
    private static final String LOCATION = "location";
    private static final String SUBLOCATION = "sublocation";
    private static final String EMPLOYEE = "employee";


    public DbHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
   /*    SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + LOCATION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SUBLOCATION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + EMPLOYEE);

        String CREATE_LOCATION_TABLE = "CREATE TABLE " + LOCATION + "("
                + "id " + "INTEGER PRIMARY KEY AUTOINCREMENT," + "place " + " TEXT)";
        String CREATE_SUBLOCATION_TABLE = "CREATE TABLE " + SUBLOCATION + "("
                + "lid " + "INTEGER ," + "dclocation" + " TEXT)";
        String CREATE_EMPLOYEE_TABLE = "CREATE TABLE " + EMPLOYEE + "("
                + "id " + "INTEGER," + "name " + "STRING,"
                + "contactnumber " + "STRING,"+ "bloodgroup " + "TEXT,"
                +"dclocation " + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_LOCATION_TABLE);
        sqLiteDatabase.execSQL(CREATE_SUBLOCATION_TABLE);
        sqLiteDatabase.execSQL(CREATE_EMPLOYEE_TABLE);*/
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	/*	// Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LABELS);
  
        // Create tables again
        onCreate(db);*/
		
	}
	
	 /**
     * Insert data to table
     * */
    public void prePoulateData(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + LOCATION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SUBLOCATION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + EMPLOYEE);

        String CREATE_LOCATION_TABLE = "CREATE TABLE " + LOCATION + "("
                + "id " + "INTEGER PRIMARY KEY AUTOINCREMENT," + "place " + " TEXT)";
        String CREATE_SUBLOCATION_TABLE = "CREATE TABLE " + SUBLOCATION + "("
                + "lid " + "INTEGER ," + "dclocation" + " TEXT)";
        String CREATE_EMPLOYEE_TABLE = "CREATE TABLE " + EMPLOYEE + "("
                + "id " + "INTEGER," + "name " + "STRING,"
                + "contactnumber " + "STRING,"+ "bloodgroup " + "TEXT,"
                +"dclocation " + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_LOCATION_TABLE);
        sqLiteDatabase.execSQL(CREATE_SUBLOCATION_TABLE);
        sqLiteDatabase.execSQL(CREATE_EMPLOYEE_TABLE);

        ContentValues locations = new ContentValues();
        ContentValues sublocations = new ContentValues();
        ContentValues empvalues = new ContentValues();


        locations.put("place", "Chennai");
        sqLiteDatabase.insert(LOCATION, null, locations);


        locations.put("place", "Mumbai");
        sqLiteDatabase.insert(LOCATION, null, locations);

        sublocations.put("lid", 1);
        sublocations.put("dclocation", "MahindraCity");
        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);

        sublocations.put("lid", 1);
        sublocations.put("dclocation", "Shollinganallur");
        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);

        sublocations.put("lid", 2);
        sublocations.put("dclocation", "Narimanpoint");
        sqLiteDatabase.insert(SUBLOCATION, null, sublocations);

        empvalues.put("id",1);
        empvalues.put("name","RAM");
        empvalues.put("contactnumber","9495435433");
        empvalues.put("bloodgroup","A+");
        empvalues.put("dclocation","MahindraCity");
        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);

        empvalues.put("id",2);
        empvalues.put("name","Ganesh");
        empvalues.put("contactnumber","9493435733");
        empvalues.put("bloodgroup","A+");
        empvalues.put("dclocation","MahindraCity");
        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);

        empvalues.put("id",3);
        empvalues.put("name","Hari");
        empvalues.put("contactnumber","8775844435");
        empvalues.put("bloodgroup","B+");
        empvalues.put("dclocation","Narimanpoint");
        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);

        empvalues.put("id",4);
        empvalues.put("name","Haran");
        empvalues.put("contactnumber","8685845485");
        empvalues.put("bloodgroup","AB-");
        empvalues.put("dclocation","Shollinganallur");
        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);

        empvalues.put("id",5);
        empvalues.put("name","Shiv");
        empvalues.put("contactnumber","9485845485");
        empvalues.put("bloodgroup","B-");
        empvalues.put("dclocation","Narimanpoint");
        sqLiteDatabase.insert(EMPLOYEE, null, empvalues);
        sqLiteDatabase.close();

        System.out.println("DB success");
    }

    /**
     * Getting all getAllLocations
     * returns list of Locations
     * */
    public List<String> getAllLocations(){
        List<String> place = new ArrayList<String>();

        // Select All Query
        String selectQuery = "SELECT place FROM " + LOCATION;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                place.add(cursor.getString(cursor.getColumnIndex("place")));
            } while (cursor.moveToNext());
        }

        // closing connection
        cursor.close();
        db.close();

        // returning place
        return place;
    }

    /**
     * Getting  Location ID from location table
     * */
    public  int getlocID(String location)
    {

        String selectQuery = "SELECT id FROM " + LOCATION +" where "+
                "place = "+"'"+location +"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor1 = db.rawQuery(selectQuery, null);
        int locId=0;

        if (cursor1.moveToFirst()) {
            do {
                locId=cursor1.getInt(cursor1.getColumnIndex("id"));
            } while (cursor1.moveToNext());
        }

        cursor1.close();
        db.close();
        return locId;
    }


    /**
     * Getting  SubLocation details  from sublocation table
     * */
    public List<String> getSubLocation(int locId){
        List<String> subLocDetails = new ArrayList<String>();
        // Select All Query
        String subLocQuery = "SELECT dclocation FROM " + SUBLOCATION + " where lid = "+ "'"+locId+"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor2 = db.rawQuery(subLocQuery, null);

        // looping through all rows and adding to list
        if (cursor2.moveToFirst()) {
            do {
                subLocDetails.add(cursor2.getString(cursor2.getColumnIndex("dclocation")));
            } while (cursor2.moveToNext());
        }
        // returning subloc details
        cursor2.close();
        db.close();
        return subLocDetails;
    }


    /**
     * Getting  Employee details  from Employee table
     * */
    public ArrayList<HashMap<String, String>> getEmployeeDetails(String subLocation,String bloodGroup){

        // Select All Query
        String subLocQuery = "SELECT name,contactnumber,dclocation FROM " + EMPLOYEE +
                " where dclocation = "+"'"+subLocation +"'"+ "" +
                " and bloodgroup = "+ "'"+bloodGroup +"'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor3 = db.rawQuery(subLocQuery, null);
        ArrayList<HashMap<String, String>> empList = new ArrayList<>();

        if (cursor3.moveToFirst()) {

            do {

                HashMap<String,String> emp = new HashMap<>();
                emp.put("name",cursor3.getString(cursor3.getColumnIndex("name")));
                emp.put("contactnumber",cursor3.getString(cursor3.getColumnIndex("contactnumber")));
                emp.put("dclocation",cursor3.getString(cursor3.getColumnIndex("dclocation")));
                empList.add(emp);
            } while (cursor3.moveToNext());
        }
        // returning subloc details
        cursor3.close();
        db.close();
        return empList;
    }

    public SQLiteDatabase getDb() {
        return this.getReadableDatabase();
    }
}
