package com.app.bb;

import java.io.Serializable;

public class Employee implements Serializable {

    int id;
    String name;
    String contactnumber;
    String bloodgroup;
    String dclocation;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactnumber() {
        return contactnumber;
    }

    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getDclocation() {
        return dclocation;
    }

    public void setDclocation(String dclocation) {
        this.dclocation = dclocation;
    }
}
