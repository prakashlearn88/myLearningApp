package com.app.bb;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import bb.R;

public class MyAppActivity extends Activity implements
		OnItemSelectedListener {

	// Spinner element
	Spinner spinner1;
    Spinner spinner2;
    Spinner spinner3;
	DbHelper db=null,db1 =null;
    Intent intent;
    int locId;
    List<String> bloodGroupList=null;
			// Add button
	Button searchButton;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spinner_ex3);

		// Spinner element
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner3 = (Spinner) findViewById(R.id.spinner3);

		// searchButton
        searchButton = (Button) findViewById(R.id.btn_srch);
        spinner2.setOnItemSelectedListener(this);
		// Spinner click listener

        spinner1.setOnItemSelectedListener( new OnItemSelectedListener() {
			public void onItemSelected(
					AdapterView<?> parent, View view, int position, long id) {
               // int iCurrentSelection = spinner1.getSelectedItemPosition();
               // System.out.println(iCurrentSelection);
			    //if(iCurrentSelection!=position) {
                    locId = db.getlocID(String.valueOf(spinner1.getSelectedItem()));
                    System.out.println(locId);
                    List<String> sublocList = null;
                    sublocList = db.getSubLocation(locId);
                    System.out.println(sublocList);
                    ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(getApplicationContext(),
                            android.R.layout.simple_spinner_item, sublocList);
                    dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    dataAdapter1.notifyDataSetChanged();
                    spinner2.setAdapter(dataAdapter1);
                }
                //iCurrentSelection = position;
			//}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

        bloodGroupList=new ArrayList<>();
        bloodGroupList.add("A+");
        bloodGroupList.add("A-");
        bloodGroupList.add("B+");
        bloodGroupList.add("B-");
        bloodGroupList.add("AB-");
        bloodGroupList.add("AB+");
        bloodGroupList.add("O+");
        bloodGroupList.add("O-");
        System.out.println("populate --> bloodGroupList");
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, bloodGroupList);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dataAdapter2.notifyDataSetChanged();
        spinner3.setAdapter(dataAdapter2);
        spinner3.setOnItemSelectedListener(this);

        loadSpinnerData();


		searchButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
			    String subLocation= String.valueOf(spinner2.getSelectedItem());
                String bloodGroup= String.valueOf(spinner3.getSelectedItem());
                    System.out.println("subLocation-->"+subLocation);
                    System.out.println("bloodGroup-->"+bloodGroup);
				// database handler
					DbHelper db = new DbHelper(getApplicationContext());
                ArrayList<HashMap<String, String>> emp=db.getEmployeeDetails(subLocation,bloodGroup);

                intent = new Intent(MyAppActivity.this, DetailsActivity.class);
                intent.putExtra("dcLocation",String.valueOf(spinner2.getSelectedItem()));
                intent.putExtra("bloodGroup",String.valueOf(spinner3.getSelectedItem()));
                startActivity(intent);
                if(emp.size()==0)
                    Toast.makeText(getApplicationContext(), "No RecordFound",Toast.LENGTH_SHORT).show();

				}


		});
	}

	/**
	 * Function to load the spinner data from SQLite database
	 * */
	private void loadSpinnerData() {
		// database handler
		db=new DbHelper(getApplicationContext());
		db.prePoulateData();

		List<String> lables = db.getAllLocations();


		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, lables);

		dataAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		// attaching data adapter to spinner
        spinner1.setAdapter(dataAdapter);

		db.close();

	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {


           }

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {

	}
}
