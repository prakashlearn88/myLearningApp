package com.example.dao;

import android.content.Context;
import android.os.AsyncTask;

import com.example.myfirstapp.AndroidSpinnerExampleActivity;

import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;


@Database(entities = {EmployeeDetails.class,LocationDetails.class,SubLocationDetails.class}, version = 1, exportSchema = false)
public abstract class BloodBankDatabase extends RoomDatabase {

    private static volatile BloodBankDatabase INSTANCE;

    public abstract EmployeeBloodGroupDAO dataDao();

   public static BloodBankDatabase getDatabase(final Context context) {
       System.out.println("DB instance Creation started");
       if (INSTANCE == null) {
           synchronized (BloodBankDatabase.class) {
               if (INSTANCE == null) {
                   INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                           BloodBankDatabase.class, "bb_db")
                           .build();
               }
           }
       }
       System.out.println("DB instance Creation successfull");
       new PopulateDbAsync(INSTANCE).execute();
       return INSTANCE;
    }
    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final EmployeeBloodGroupDAO employeeBloodGroupDAO;

        PopulateDbAsync(BloodBankDatabase db) {
            employeeBloodGroupDAO = db.dataDao();
        }

        @Override
        protected Void doInBackground(final Void... params) {
            System.out.println("DB Record Creation started");
            employeeBloodGroupDAO.insertMultipleLocations(EmployeeBloodGroupDAO.populateLocationData());
            employeeBloodGroupDAO.insertMultipleSubLocations(EmployeeBloodGroupDAO.populateSubLocationData());
            employeeBloodGroupDAO.insertMultipleEmployeeDetails(EmployeeBloodGroupDAO.populateEmployeeData());
            System.out.println("DB Record Insertion complted");
            return null;
        }
    }
}

