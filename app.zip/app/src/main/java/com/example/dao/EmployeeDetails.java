package com.example.dao;

import java.io.Serializable;
import java.math.BigInteger;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Employee")
public class EmployeeDetails implements Serializable {


    public EmployeeDetails(int empid, @NonNull String empname, String contactnumber, @NonNull String bloodgroup, @NonNull String dclocation) {
        this.empid = empid;
        this.empname = empname;
        this.contactnumber = contactnumber;
        this.bloodgroup = bloodgroup;
        this.dclocation = dclocation;
    }

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "empid")
    private int empid;

    @NonNull
    @ColumnInfo(name = "empname")
    private String empname;


    @NonNull
    @ColumnInfo(name = "contactnumber")
    private String contactnumber;

    @NonNull
    @ColumnInfo(name = "bloodgroup")
    private String bloodgroup;

    @NonNull
    @ColumnInfo(name = "dclocation")
    private String dclocation;

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    @NonNull
    public String getEmpname() {
        return empname;
    }

    public void setEmpname(@NonNull String empname) {
        this.empname = empname;
    }

    public String getContactnumber() {
        return contactnumber;
    }

    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }
    @NonNull
    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(@NonNull String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    @NonNull
    public String getDclocation() {
        return dclocation;
    }

    public void setDclocation(@NonNull String dclocation) {
        this.dclocation = dclocation;
    }


}