package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import static androidx.room.OnConflictStrategy.IGNORE;

@Dao
public interface EmployeeBloodGroupDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertLocation(LocationDetails locationDetails);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertSubLocation(SubLocationDetails locationDetails);

    @Delete
    void deleteLocation(LocationDetails location);

    @Delete
    void deleteSubLocation(SubLocationDetails location);

    @Query("DELETE FROM locality")
    void deleteAllLocation();

    @Query("DELETE FROM sublocation")
    void deleteAllSubLocation();

    @Query("DELETE FROM employee")
    void deleteAllEmployee();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMultipleLocations(List<LocationDetails> locationDetailsList);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMultipleSubLocations(List<SubLocationDetails> subLocationDetailsList);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertMultipleEmployeeDetails(List<EmployeeDetails> employeeDetailsList);

    @Query("SELECT location from locality ORDER BY location")
    LiveData<List<String>> getAllLocations();

    @Query("SELECT id from locality Where location =:location")
    List<Integer> getLocationId(String location);

    @Query("SELECT dclocation from SubLocation Where lid =:id ORDER BY dcLocation")
    LiveData<List<String>> getAllsubLocations(int id);

    @Query("SELECT * from Employee Where bloodGroup =:bloodGroup and dcLocation=:dcLocation")
    LiveData<List<EmployeeDetails>> getEmployeeDetails(String bloodGroup,String dcLocation);

    public static ArrayList<LocationDetails> populateLocationData() {
        ArrayList<LocationDetails> locationDetailsList = new ArrayList<LocationDetails>();
        LocationDetails ld = new LocationDetails(1, "Chennai");
        LocationDetails ld1 = new LocationDetails(2, "Mumbai");
        locationDetailsList.add(ld);
        locationDetailsList.add(ld1);
        return locationDetailsList;
    }

    public static ArrayList<SubLocationDetails> populateSubLocationData() {
        ArrayList<SubLocationDetails> sublocationDetailsList = new ArrayList<SubLocationDetails>();
        SubLocationDetails sld = new SubLocationDetails(1, "Shollingalnallur");
        SubLocationDetails sld1 = new SubLocationDetails(1, "Mahindra World City-Chengalpattu");
        SubLocationDetails sld2 = new SubLocationDetails(2, "Nariman Point");
        sublocationDetailsList.add(sld);
        sublocationDetailsList.add(sld1);
        sublocationDetailsList.add(sld2);
        return sublocationDetailsList;
    }

    public static ArrayList<EmployeeDetails> populateEmployeeData() {

        ArrayList<EmployeeDetails> empDetailsList = new ArrayList<>();

        EmployeeDetails emp1 = new EmployeeDetails(1, "Ram", "9940431021", "A1+", "Shollinganallur");
        EmployeeDetails emp2 = new EmployeeDetails(2, "Hari", "9945649301", "B+", "Mahindra World City-Chengalpattu");
        EmployeeDetails emp3 = new EmployeeDetails(3, "Haran", "9945649301", "B-", "Nariman Point");

        empDetailsList.add(emp1);
        empDetailsList.add(emp2);
        empDetailsList.add(emp3);
        return empDetailsList;
    }
}


