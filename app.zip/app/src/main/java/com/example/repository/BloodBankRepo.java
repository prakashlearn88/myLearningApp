package com.example.repository;


import android.app.Application;
import android.os.AsyncTask;

import com.example.dao.BloodBankDatabase;
import com.example.dao.EmployeeBloodGroupDAO;
import com.example.dao.LocationDetails;

import java.util.List;

import androidx.lifecycle.LiveData;

public class BloodBankRepo {
    private EmployeeBloodGroupDAO employeeBloodGroupDAO;
    private LiveData<List<String>> locationDetails;
    private LiveData<List<String>> subLocationDetails;
    private List<Integer> tempsublocationDetails=null;

      public BloodBankRepo(Application application) {
        BloodBankDatabase db = BloodBankDatabase.getDatabase(application);
        employeeBloodGroupDAO = db.dataDao();
        locationDetails = employeeBloodGroupDAO.getAllLocations();

        //empDetails = employeeBloodGroupDAO.getEmployeeDetails();
        List<String> locations =locationDetails.getValue();
        for(String location:locations)
        {
            tempsublocationDetails.addAll(employeeBloodGroupDAO.getLocationId(location));
        }
        for(int i:tempsublocationDetails)
        {
            subLocationDetails = employeeBloodGroupDAO.getAllsubLocations(i);
        }

    }

    public LiveData<List<String>> getAllLocations() {return locationDetails;}
    public LiveData<List<String>> getMyLocations() {return locationDetails;}
    public LiveData<List<String>> getAllSubLocations() {
        return subLocationDetails;
    }

    //LiveData<List<String>> getEmployeeDetails() {return empDetails;}


}




