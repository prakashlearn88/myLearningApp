package com.loyalty;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController
{
       @Autowired
    UserRepository userRepository;
    //Create
    @RequestMapping(value = "/user", method = RequestMethod.POST)
    public User createStudent(@RequestBody User student)
    {
        return userRepository.save(student);
    }
    
    //Read
    @RequestMapping(value="/user/{id}", method = RequestMethod.GET)
    public User getStudentById(@PathVariable long id)
    {
        return userRepository.findOne(id);
    }
    
    @RequestMapping(value="/users", method = RequestMethod.GET)
    public List<User> getAllStudents()
    {
        return (List<User>)userRepository.findAll();
    }
    
    //Update
    @RequestMapping(value = "/user", method = RequestMethod.PUT)
    public User updateStudent(@RequestBody User student)
    {
        return userRepository.save(student);
    }
    
    //Delete
    @RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
    public void deleteStudent(@PathVariable long id)
    {
        userRepository.delete(id);
    }
}
