package com.loyalty;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource
public interface UserRepository extends CrudRepository<User, Long> 
{
	@Query("select points from User d where d.id = ?1")
	public long findPoints(long i);
	
	@Query(value="select p from User p")
	public List<User> findWithPageable(Pageable pageable);
}
