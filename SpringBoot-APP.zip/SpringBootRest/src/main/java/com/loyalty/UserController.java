package com.loyalty;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	@Autowired
	UserRepository userRepository;
	@Autowired
	TransactionRepository transactionRepository;

	// Create
	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public User createStudent(@RequestBody User user) {
		System.out.println("Email address-->" + user.getEmailaddress());
		System.out.println("Id->" + user.getId());
		System.out.println("Email address-->" + user.getMobilenumber());
		System.out.println("Email address-->" + user.getNickname());
		user.setPoints(100);
		return userRepository.save(user);
	}

	// Read
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public User getStudentById(@PathVariable long id) {
		return userRepository.findOne(id);
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public List<User> getAllStudents() {
		return (List<User>) userRepository.findAll();
	}

	@RequestMapping(value = "/users/points/", method = RequestMethod.GET)
	public long getPoints() {
		List<User> usr = userRepository.findWithPageable(new PageRequest(0, 1, Direction.DESC, "id"));
		System.out.println("Id-->" + usr.get(0).getId());
		return userRepository.findPoints(usr.get(0).getId());
	}
	
	/*
	 * public List<User> getTransDetails() { List<User> usr =
	 * userRepository.findWithPageable(new PageRequest(0, 1, Direction.DESC, "id"));
	 * System.out.println("Id-->" + usr.get(0).getId()); return
	 * transactionRepository.findAll()((usr.get(0).getId())); }
	 */

	// Update
	@RequestMapping(value = "/user/collect/", method = RequestMethod.PUT)
	public User collectPoints() {
		List<User> users = userRepository.findWithPageable(new PageRequest(0, 1, Direction.DESC, "id"));
		User user = users.get(0);
		System.out.println("Collect Points -->" + user.getPoints());
		user.setPoints(user.getPoints() + 100);
		return userRepository.save(user);
	}

	@RequestMapping(value = "/user/redeem/{id}", method = RequestMethod.PUT)
	public User redeemPoints() {
		List<User> users = userRepository.findWithPageable(new PageRequest(0, 1, Direction.DESC, "id"));
		User user = users.get(0);
		System.out.println("Reeedem Points -->" + user.getPoints());
		if (user.getPoints() > 1000) {
			user.setPoints(user.getPoints() - 100);
			return userRepository.save(user);
		} else
			return null;

	}

	// Delete
	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	public void deleteStudent(@PathVariable long id) {
		userRepository.delete(id);
	}
}
