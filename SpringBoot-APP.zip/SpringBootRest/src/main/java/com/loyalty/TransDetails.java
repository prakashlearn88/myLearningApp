package com.loyalty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TransDetails")
public class TransDetails {

	
		@Column(name = "id", nullable = false)
		private long id;

		@Column(name = "points", nullable = false)
		private String points;

		@Column(name = "transtype", nullable = false)
		private String transtype;



}
